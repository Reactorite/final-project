import QuizDataType from './QuizDataType';

export interface QuizesDataType {
    [quizId: string]: QuizDataType;
};