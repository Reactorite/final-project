export default interface HoverState {
    [key: number]: boolean;  // Explicit typing for the state object
}