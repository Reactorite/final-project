import React from "react";

const Quiz = () => {

  return (
      <div>
       <p>Welcome, to the best IQuiz site ever.</p>
      </div>
  );
};

export default Quiz;
